
import Head from 'next/head'
import Image from 'next/image'
import Link from 'next/link'

export default function Home() {
  return (
    <>
      <Head>
        <title>Dzire Menswear Outlet</title>
      </Head>
      <main className="min-h-screen bg-blue-50 font-sans">
        <header className="bg-blue-700 text-white p-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">Dzire Menswear</h1>
          <nav className="space-x-4">
            <Link href="/">Home</Link>
            <Link href="#about">About</Link>
            <Link href="#products">Products</Link>
            <Link href="#contact">Contact</Link>
          </nav>
        </header>

        <section id="about" className="p-8 text-center">
          <h2 className="text-3xl font-semibold mb-4">About Us</h2>
          <p>We offer high-quality imported t-shirts for modern men. Explore our latest collection at affordable prices.</p>
        </section>

        <section id="products" className="p-8">
          <h2 className="text-3xl font-semibold mb-6 text-center">Products</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl shadow-md p-4">
              <Image src="/white-tshirt.jpg" alt="White T-Shirt" width={500} height={300} className="rounded" />
              <h3 className="text-xl mt-4 font-bold">White Imported T-Shirt</h3>
              <p>Made in China. Stylish, comfortable and durable.</p>
            </div>
            <div className="bg-white rounded-xl shadow-md p-4">
              <Image src="/black-tshirt.jpg" alt="Black T-Shirt" width={500} height={300} className="rounded" />
              <h3 className="text-xl mt-4 font-bold">Black Imported T-Shirt</h3>
              <p>Made in China. Elegant, premium cotton wear.</p>
            </div>
          </div>
        </section>

        <section id="contact" className="p-8 bg-blue-100">
          <h2 className="text-3xl font-semibold mb-4 text-center">Contact Us</h2>
          <form className="max-w-xl mx-auto space-y-4">
            <input className="w-full p-2 border rounded" type="text" placeholder="Your Name" required />
            <input className="w-full p-2 border rounded" type="email" placeholder="Your Email" required />
            <textarea className="w-full p-2 border rounded" placeholder="Your Message" required></textarea>
            <button className="bg-blue-600 text-white px-4 py-2 rounded" type="submit">Send</button>
          </form>
        </section>

        <footer className="text-center p-4 text-sm text-gray-500">
          &copy; 2025 Dzire Menswear Outlet
        </footer>
      </main>
    </>
  )
}
